<div>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success alert-styled-left">
            <button type="button" class="close" data-dismiss="alert"><span>×</span><span class="sr-only">Close</span></button>
            <?php echo e(session()->get('success')); ?>

        </div>
    <?php endif; ?>


    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger alert-styled-left">
            <button type="button" class="close" data-dismiss="alert"><span>×</span><span class="sr-only">Close</span></button>
            <?php echo e(session()->get('error')); ?>

        </div>
    <?php endif; ?>



</div>