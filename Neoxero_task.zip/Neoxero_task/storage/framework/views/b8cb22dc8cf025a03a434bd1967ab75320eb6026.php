<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title m-b-0">Companies</h5>
                    <a href="/companies/create" type="button" class="btn btn-primary btn-sm">add new</a>
                </div>
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th>logo</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">websit</th>
                        <th>action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if($companies->isNotEmpty()): ?>
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><img src="<?php echo e(!empty($company->comp_logo)?'/storage/' . $company->comp_logo:""); ?>" width="100px" height="100px"></td>
                                <td><?php echo e($company->comp_name); ?></td>
                                <td><?php echo e($company->comp_email); ?></td>
                                <td><?php echo e($company->comp_website); ?></td>
                                <td>
                                    <a href="/companies/<?php echo e($company->comp_id); ?>/edit" type="button" class="btn btn-cyan btn-sm">Edit</a>
                                    <form action="<?php echo e(url('companies', [$company->comp_id])); ?>" method="POST">
                                        <?php echo e(method_field('DELETE')); ?>

                                        <?php echo csrf_field(); ?>

                                        <input type="submit" class="btn btn-danger btn-sm" value="Delete"/>
                                    </form>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr> <td colspan="6">No company added yet.</td></tr>
                        <?php endif; ?>


                    </tbody>
                </table>

            </div>

        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    <?php echo e($companies->links()); ?>



                </ul>
            </nav>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>