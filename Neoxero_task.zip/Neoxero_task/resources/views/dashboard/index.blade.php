@extends('layouts.master')

@section('content')
<h1>dashboard</h1>

@endsection